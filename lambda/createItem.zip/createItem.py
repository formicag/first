"""
Lambda function to create a new shopping list item in DynamoDB.

This function adds a new item to the ShoppingList table with auto-generated
itemId and timestamps. It automatically categorizes items using Amazon Bedrock.
"""

import json
import boto3
import uuid
import os
from datetime import datetime
from decimal import Decimal
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
bedrock_runtime = boto3.client('bedrock-runtime', region_name='eu-west-1')
table = dynamodb.Table('ShoppingList')

# Bedrock model configuration - configurable via environment variable
BEDROCK_MODEL_ID = os.environ.get(
    'BEDROCK_MODEL',
    'anthropic.claude-3-haiku-20240307-v1:0'
)

# UK Shopping Centre Standard Categories
UK_CATEGORIES = [
    "Fresh Produce - Fruit",
    "Fresh Produce - Vegetables",
    "Fresh Produce - Herbs & Salads",
    "Meat & Poultry",
    "Fish & Seafood",
    "Dairy & Eggs",
    "Bakery & Bread",
    "Frozen Foods",
    "Pantry & Dry Goods",
    "Canned & Jarred",
    "Snacks & Confectionery",
    "Beverages",
    "Alcohol & Wine",
    "Health & Beauty",
    "Household & Cleaning",
    "Baby & Child"
]

# Rule-based fallback categorization - NEVER returns "Uncategorized"
def fallback_categorize(item_name):
    """
    Rule-based categorizer for when AI fails. NEVER returns "Uncategorized".
    Uses keyword matching and smart defaults.
    """
    item_lower = item_name.lower().strip()

    # Dairy & Eggs
    if any(word in item_lower for word in ['milk', 'butter', 'cheese', 'yogurt', 'yoghurt', 'cream', 'eggs', 'egg']):
        return "Dairy & Eggs"

    # Meat & Poultry
    if any(word in item_lower for word in ['chicken', 'beef', 'pork', 'lamb', 'turkey', 'sausage', 'bacon', 'ham', 'chops', 'steak', 'mince']):
        return "Meat & Poultry"

    # Fish & Seafood
    if any(word in item_lower for word in ['salmon', 'tuna', 'cod', 'fish', 'prawns', 'shrimp', 'seafood']):
        # Check if it's canned
        if any(word in item_lower for word in ['canned', 'tinned', 'can', 'tin']):
            return "Canned & Jarred"
        return "Fish & Seafood"

    # Bakery & Bread
    if any(word in item_lower for word in ['bread', 'baguette', 'rolls', 'buns', 'bagels', 'croissant', 'rye']):
        return "Bakery & Bread"

    # Fresh Produce - Fruit
    if any(word in item_lower for word in ['apple', 'banana', 'orange', 'grape', 'berry', 'melon', 'mango', 'pear', 'peach', 'plum', 'kiwi', 'pineapple', 'lemon', 'lime']):
        return "Fresh Produce - Fruit"

    # Fresh Produce - Vegetables
    if any(word in item_lower for word in ['potato', 'carrot', 'onion', 'tomato', 'pepper', 'broccoli', 'cauliflower', 'cabbage', 'lettuce', 'cucumber', 'courgette', 'aubergine', 'mushroom', 'vegetables']):
        # Check if frozen
        if 'frozen' in item_lower:
            return "Frozen Foods"
        return "Fresh Produce - Vegetables"

    # Fresh Produce - Herbs & Salads
    if any(word in item_lower for word in ['herb', 'basil', 'parsley', 'coriander', 'mint', 'salad', 'tzatziki', 'hummus']):
        return "Fresh Produce - Herbs & Salads"

    # Frozen Foods
    if any(word in item_lower for word in ['frozen', 'ice cream', 'chips']) and 'frozen' in item_lower:
        return "Frozen Foods"

    # Health & Beauty
    if any(word in item_lower for word in ['shampoo', 'soap', 'toothpaste', 'toothbrush', 'deodorant', 'face wash', 'cotton wool', 'hand wash', 'cetirizine', 'contact lens', 'neutrogena']):
        return "Health & Beauty"

    # Household & Cleaning
    if any(word in item_lower for word in ['cleaning', 'cleaner', 'detergent', 'washing', 'dishwasher', 'toilet', 'bleach', 'domestos', 'bags', 'bin', 'tissue', 'kitchen roll', 'air freshener']):
        return "Household & Cleaning"

    # Beverages
    if any(word in item_lower for word in ['water', 'juice', 'coffee', 'tea', 'teabags', 'cola', 'lemonade', 'drink', 'kombucha', 'kambucha', 'kefir']):
        return "Beverages"

    # Alcohol & Wine
    if any(word in item_lower for word in ['beer', 'wine', 'vodka', 'whisky', 'gin', 'rum', 'alcohol', 'cider', 'lager']):
        return "Alcohol & Wine"

    # Snacks & Confectionery
    if any(word in item_lower for word in ['chocolate', 'crisps', 'chips', 'biscuit', 'cookie', 'sweet', 'candy', 'bounty', 'snack']):
        return "Snacks & Confectionery"

    # Canned & Jarred
    if any(word in item_lower for word in ['canned', 'tinned', 'can', 'tin', 'jar', 'jarred', 'tuna can']):
        return "Canned & Jarred"

    # Pantry & Dry Goods (most generic fallback - handles: rice, pasta, flour, lentils, etc.)
    logger.warning(f"No specific category match for '{item_name}'. Using Pantry & Dry Goods as default.")
    return "Pantry & Dry Goods"


def lambda_handler(event, context):
    """
    Create a new shopping list item.

    Expected input (JSON):
    {
        "userId": "Gianluca",
        "itemName": "Eggs",
        "quantity": 12,
        "category": "Dairy"  // optional
    }

    Returns:
        dict: Response with status code and created item details
    """
    try:
        # Parse input
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event

        # Get userId from request body (allows frontend to specify which user's list)
        user_id = body.get('userId', 'TestUser')

        logger.info(f"Creating item for userId: {user_id}")

        # Validate required fields
        required_fields = ['itemName', 'quantity']
        for field in required_fields:
            if field not in body:
                logger.error(f"Missing required field: {field}")
                return {
                    'statusCode': 400,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({
                        'error': f'Missing required field: {field}'
                    })
                }

        # Extract and validate data
        item_name = body['itemName']
        quantity = body['quantity']
        custom_prompt = body.get('customPrompt', '')  # Optional AI prompt customization
        context_items = body.get('contextItems', [])  # Household-specific context
        use_uk_english = body.get('useUKEnglish', True)  # UK English preference
        strict_categories = body.get('strictCategories', True)  # Strict UK categories

        # Validate quantity is a positive number
        try:
            quantity = int(quantity)
            if quantity <= 0:
                raise ValueError("Quantity must be positive")
        except (ValueError, TypeError) as e:
            logger.error(f"Invalid quantity: {quantity}")
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'error': 'Quantity must be a positive number'
                })
            }

        # Use AI to process item name: spell check, capitalize, and categorize
        logger.info(f"Processing item with AI: {item_name}")
        ai_result = process_item_with_ai(
            item_name,
            custom_prompt,
            context_items,
            use_uk_english,
            strict_categories
        )

        corrected_name = ai_result['correctedName']
        estimated_price = ai_result['estimatedPrice']
        category = ai_result['category']

        logger.info(f"AI processed: '{item_name}' → '{corrected_name}' (£{estimated_price:.2f}, {category})")

        # Check for duplicates - query all items for this user
        logger.info(f"Checking for duplicates for user {user_id}")
        try:
            response = table.query(
                KeyConditionExpression='userId = :userId',
                ExpressionAttributeValues={
                    ':userId': user_id
                }
            )

            existing_items = response.get('Items', [])
            normalized_corrected = corrected_name.lower().strip()

            # Check if any existing item matches (case-insensitive)
            for existing_item in existing_items:
                existing_name = existing_item.get('itemName', '').lower().strip()
                if existing_name == normalized_corrected:
                    logger.warning(f"Duplicate detected: '{corrected_name}' already exists for {user_id}")
                    return {
                        'statusCode': 409,  # Conflict status code
                        'headers': {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        },
                        'body': json.dumps({
                            'error': 'Duplicate item',
                            'message': f"'{corrected_name}' is already in your shopping list",
                            'existingItem': {
                                'itemName': existing_item.get('itemName'),
                                'quantity': int(existing_item.get('quantity', 1)),
                                'itemId': existing_item.get('itemId')
                            }
                        })
                    }
        except Exception as e:
            logger.error(f"Error checking for duplicates: {str(e)}")
            # Continue with creation even if duplicate check fails

        # Generate UUID and timestamp
        item_id = str(uuid.uuid4())
        added_date = datetime.utcnow().isoformat() + 'Z'

        # Create item object with AI-processed data
        item = {
            'userId': user_id,
            'itemId': item_id,
            'itemName': corrected_name,  # Use AI-corrected name
            'estimatedPrice': Decimal(str(estimated_price)),  # Convert to Decimal for DynamoDB
            'quantity': quantity,
            'category': category,  # Use AI-assigned category
            'bought': False,
            'addedDate': added_date
        }

        # Insert item into DynamoDB
        logger.info(f"Creating item for user {user_id}: {corrected_name}")
        table.put_item(Item=item)

        logger.info(f"Successfully created item {item_id}")

        # Return success response with AI processing details
        # Convert Decimal to float for JSON serialization
        response_item = {
            'userId': item['userId'],
            'itemId': item['itemId'],
            'itemName': item['itemName'],
            'estimatedPrice': float(item['estimatedPrice']),
            'quantity': item['quantity'],
            'category': item['category'],
            'bought': item['bought'],
            'addedDate': item['addedDate']
        }

        return {
            'statusCode': 201,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Item created successfully',
                'item': response_item,
                'aiProcessing': {
                    'originalName': item_name,
                    'correctedName': corrected_name,
                    'estimatedPrice': estimated_price,
                    'wasSpellCorrected': item_name != corrected_name,
                    'category': category
                }
            })
        }

    except Exception as e:
        logger.error(f"Error creating item: {str(e)}", exc_info=True)
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e)
            })
        }


def process_item_with_ai(item_name, custom_prompt='', context_items=[], use_uk_english=True, strict_categories=True):
    """
    Use Amazon Bedrock to process a grocery item:
    1. Correct spelling
    2. Capitalize first letter of each word
    3. Categorize into UK shopping centre aisle

    Args:
        item_name: Name of the grocery item
        custom_prompt: Optional custom instructions to add to the AI prompt
        context_items: List of {term, meaning} dictionaries for household-specific context
        use_uk_english: Whether to enforce UK English spelling and terminology
        strict_categories: Whether to strictly use UK supermarket category names

    Returns:
        dict: Dictionary with 'correctedName' and 'category' keys
    """
    # Build categories string
    categories_str = ", ".join(UK_CATEGORIES)

    # Base prompt
    base_prompt = f"""You are a UK shopping assistant helping to process grocery items.

For this item: '{item_name}'"""

    # Add UK English instruction if enabled
    if use_uk_english:
        base_prompt += """

IMPORTANT: Use UK English spelling and terminology.
Examples: colour (not color), flavour (not flavor), courgette (not zucchini), aubergine (not eggplant)"""

    # Add household context if provided
    if context_items:
        base_prompt += "\n\nHOUSEHOLD CONTEXT (Gianluca and Nicole's specific meanings):\n"
        for item in context_items:
            base_prompt += f"- \"{item['term']}\" means {item['meaning']}\n"

    base_prompt += """

TASK 1 - Spelling Correction:
- Correct any spelling mistakes
- If spelling is already correct, keep the original name
- Ensure proper spacing

TASK 2 - Capitalization:
- Capitalize the FIRST letter of EACH word
- Examples: "pork chops" → "Pork Chops", "tomato" → "Tomato"

TASK 3 - Price Estimation:
- Estimate the typical price at Sainsbury's UK for this item
- Consider the quantity mentioned (if any) or assume standard pack size
- Return price in GBP (pounds) as a decimal number
- Examples: "Milk" → 1.25, "Bread" → 1.10, "Apples" (per kg) → 2.50
- Use typical 2024-2025 Sainsbury's pricing
- For unclear quantities, estimate for a typical single purchase unit
"""

    # Add categorization task
    if strict_categories:
        base_prompt += f"""
TASK 4 - Categorization:
- Categorize into ONE of these UK shopping centre aisles: {categories_str}
- Use standard UK supermarket terminology
- Think about where this would be found in a typical Tesco, Sainsbury's, or Asda
- IMPORTANT: Consider the form/preparation:
  * Fresh items (fresh fish, fresh meat, fresh produce) → use Fresh/Fish/Meat categories
  * Canned items (tinned tuna, canned beans, jarred sauce) → use "Canned & Jarred"
  * Frozen items (frozen peas, ice cream) → use "Frozen Foods"
  * Ambient packaged items (pasta, rice, flour) → use "Pantry & Dry Goods"
- If item name includes "tuna" without specifying fresh → assume CANNED (goes to "Canned & Jarred")
- If item name includes "salmon" without specifying fresh → assume FRESH (goes to "Fish & Seafood")"""
    else:
        base_prompt += f"""
TASK 4 - Categorization:
- Categorize into ONE of these UK shopping centre aisles: {categories_str}
- You may suggest alternative category names if more appropriate"""

    # Add custom prompt if provided
    if custom_prompt and custom_prompt.strip():
        base_prompt += f"\n\nADDITIONAL INSTRUCTIONS:\n{custom_prompt.strip()}"

    base_prompt += """\n\nReturn ONLY valid JSON in this exact format:
{"correctedName": "Item Name With Proper Capitalization", "estimatedPrice": 1.25, "category": "Category Name"}"""

    # Prepare request for Claude
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 150,
        "temperature": 0,  # Deterministic output
        "messages": [
            {
                "role": "user",
                "content": base_prompt
            }
        ]
    }

    try:
        # Invoke Bedrock model
        response = bedrock_runtime.invoke_model(
            modelId=BEDROCK_MODEL_ID,
            contentType='application/json',
            accept='application/json',
            body=json.dumps(request_body)
        )

        # Parse response
        response_body = json.loads(response['body'].read())
        response_text = response_body['content'][0]['text'].strip()

        # Parse JSON response
        try:
            result = json.loads(response_text)
            corrected_name = result.get('correctedName', item_name)
            estimated_price = result.get('estimatedPrice', 0.0)  # Default to 0 if no price
            category = result.get('category', fallback_categorize(item_name))

            # Validate category is in our list
            if category not in UK_CATEGORIES:
                logger.warning(f"AI returned invalid category '{category}'. Using fallback categorization.")
                category = fallback_categorize(item_name)

            # Validate price is a positive number
            try:
                estimated_price = float(estimated_price)
                if estimated_price < 0:
                    estimated_price = 0.0
            except (ValueError, TypeError):
                logger.warning(f"Invalid price '{estimated_price}'. Using 0.0")
                estimated_price = 0.0

            return {
                'correctedName': corrected_name,
                'estimatedPrice': estimated_price,
                'category': category
            }

        except json.JSONDecodeError as je:
            logger.error(f"Invalid JSON from AI for '{item_name}': {response_text}")
            # Fallback: capitalize first letter of each word manually
            corrected_name = ' '.join(word.capitalize() for word in item_name.split())
            return {
                'correctedName': corrected_name,
                'estimatedPrice': 0.0,
                'category': fallback_categorize(item_name)
            }

    except Exception as e:
        logger.error(f"Error calling Bedrock for '{item_name}': {str(e)}")
        # Fallback: capitalize first letter of each word manually
        corrected_name = ' '.join(word.capitalize() for word in item_name.split())
        return {
            'correctedName': corrected_name,
            'estimatedPrice': 0.0,
            'category': fallback_categorize(item_name)
        }
